<?php

namespace revivalpmmp\pureentities\entity\animal;

use pocketmine\entity\Ageable;

interface Animal extends Ageable{

}