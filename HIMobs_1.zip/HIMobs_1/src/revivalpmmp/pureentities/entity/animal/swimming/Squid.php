<?php

namespace revivalpmmp\pureentities\entity\animal\swimming;

use revivalpmmp\pureentities\entity\animal\Animal;

class Squid extends \pocketmine\entity\Squid implements Animal {

}
