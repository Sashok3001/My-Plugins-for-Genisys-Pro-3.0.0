<?php

namespace revivalpmmp\pureentities\entity\monster\swimming;

use revivalpmmp\pureentities\entity\monster\Monster;
use revivalpmmp\pureentities\entity\monster\SwimmingMonster;

class Guardian extends SwimmingMonster implements Monster {
    
    // TODO: refer to the NewMobs branch for this mobs data
}
