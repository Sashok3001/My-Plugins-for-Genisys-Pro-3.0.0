<?php

namespace revivalpmmp\pureentities\entity\monster\flying;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\item\Item;
use revivalpmmp\pureentities\entity\monster\FlyingMonster;
use revivalpmmp\pureentities\entity\projectile\FireBall;
use revivalpmmp\pureentities\PureEntities;
use pocketmine\entity\Creature;
use pocketmine\entity\Entity;
use pocketmine\event\entity\ProjectileLaunchEvent;
use pocketmine\entity\ProjectileSource;
use pocketmine\level\Location;
use pocketmine\level\sound\LaunchSound;
use pocketmine\math\Vector3;
use pocketmine\Player;
use revivalpmmp\pureentities\data\Data;

class Ghast extends FlyingMonster implements ProjectileSource{
    const NETWORK_ID = Data::GHAST;

    public $width = 4;
    public $height = 4;

    public function getSpeed() : float{
        return 1.2;
    }

    public function initEntity(){
        parent::initEntity();

        $this->fireProof = true;
        $this->setMaxHealth(10);
        $this->setHealth(10);
        $this->setDamage([0, 0, 0, 0]);
    }

    public function getName(){
        return "Ghast";
    }

    public function targetOption(Creature $creature, float $distance) : bool{
        return (!($creature instanceof Player) || ($creature->isSurvival() && $creature->spawned)) && $creature->isAlive() && !$creature->closed && $distance <= 10000;
    }

    public function attackEntity(Entity $player){
        if($this->attackDelay > 30 && mt_rand(1, 32) < 4 && $this->distance($player) <= 100){
            $this->attackDelay = 0;

            $f = 2;
            $yaw = $this->yaw + mt_rand(-220, 220) / 10;
            $pitch = $this->pitch + mt_rand(-120, 120) / 10;
            $pos = new Location(
                $this->x + (-sin($yaw / 180 * M_PI) * cos($pitch / 180 * M_PI) * 0.5),
                $this->getEyeHeight(),
                $this->z +(cos($yaw / 180 * M_PI) * cos($pitch / 180 * M_PI) * 0.5),
                $yaw,
                $pitch,
                $this->level
            );
        }
    }

    public function getDrops(){
        $drops = [];
        array_push($drops, Item::get(Item::GHAST_TEAR, 0, mt_rand(0, 1)));
        array_push($drops, Item::get(Item::GUNPOWDER, 0, mt_rand(1, 2)));
		return $drops;
	}
	public function getMaxHealth() {
    return 10;
    }

}
